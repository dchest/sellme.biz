<?php
/*
Plugin Name: CR Recent posts
Description: Usage: <em>[POSTS number_of_posts category_slug_or_name]</em>, for example: <em>[POSTS 10 memoires]</em>
Author: Dmitry Chestnykh
Version: 1.1
Plugin URI: http://www.codingrobots.com
Author URI: http://sellme.ru
*/

function cr_recent_posts_get_titles($num, $category)
{
	$q = array('numberposts'=>$num);
	if (!empty($category))
		$q['category_name'] = $category;
 	$posts = get_posts($q);
 	$out = "<ul>\n";
 	foreach($posts as $p) {
		$out .= '<li><a href="'.get_permalink($p->ID).'">'.$p->post_title.'</a>'
				.' <span class="small-date">'.strftime("%b&nbsp;%d", strtotime($p->post_date)).'</span></li>'
				."\n";
	}
 	$out .= "</ul>\n";
	return $out;
}


function cr_recent_posts($content)
{
	$regex = "/\[POSTS (\d+)[ ]?(.+)?\]/";
	
	if (preg_match($regex, $content, $matches)) {
		if (count($matches) > 2)
			$category = $matches[2];
		else
			$category = '';
		$content = preg_replace($regex, cr_recent_posts_get_titles($matches[1], $category), $content);
	}
	return $content;
}


add_filter('the_content', 'cr_recent_posts');
?>