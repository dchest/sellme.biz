<?php
/*
Plugin Name: Shit Disabler
Description: Remove WLW manifest and RSD links, and WordPress version meta tag from <em>head</em>.
Author: Dmitry Chestnykh
*/

remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wp_generator');
?>
